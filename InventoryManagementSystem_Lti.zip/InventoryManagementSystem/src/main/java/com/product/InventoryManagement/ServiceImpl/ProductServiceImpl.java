package com.product.InventoryManagement.ServiceImpl;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.product.InventoryManagement.Service.ProductService;
import com.product.InventoryManagement.dao.ProductDAO;
import com.product.InventoryManagementSystem.model.Product;
@Service
@Transactional
public class ProductServiceImpl implements ProductService  {
@Autowired 
ProductDAO dao;
	 @Override
	    public Iterable<Product> getAllProducts() {
	        return dao.findAll();
	    }
	 @Override
	    public Product createProduct(Product product) {
	        return dao.save(product);
	    }
	    @Override
	    public Product findProductByProductName(String productName) {
	        return dao.findProductByProductName(productName);
	    }
		@Override
		public boolean deleteProduct() {
			// TODO Auto-generated method stub
			return dao.deleteProduct();
		}
	    
}
