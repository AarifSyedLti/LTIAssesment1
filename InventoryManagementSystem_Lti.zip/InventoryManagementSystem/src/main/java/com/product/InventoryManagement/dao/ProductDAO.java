package com.product.InventoryManagement.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.product.InventoryManagementSystem.model.Product;

@Repository
public interface ProductDAO extends JpaRepository<Product,Integer>{
	 @Query("select t from Product t where t.name=:productName")
	    Product findProductByProductName(String productName);
	 
	 @Query("delete t from Product t where t.rating=:<2")
	    boolean deleteProduct();

}
