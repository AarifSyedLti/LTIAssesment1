package com.product.InventoryManagement.Service;

import com.product.InventoryManagementSystem.model.Product;


public interface ProductService {
	  Iterable<Product> getAllProducts();
	  Product  createProduct(Product product);
	  Product findProductByProductName(String productName);
	  boolean deleteProduct();

}
