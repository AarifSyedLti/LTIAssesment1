/**
 * 
 */
/**
 * @author Administrator
 *
 */
package com.product.InventoryManagementSystem.model;