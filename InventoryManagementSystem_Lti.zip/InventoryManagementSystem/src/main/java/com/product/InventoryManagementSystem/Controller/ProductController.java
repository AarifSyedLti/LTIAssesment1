package com.product.InventoryManagementSystem.Controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.product.InventoryManagement.Service.ProductService;
import com.product.InventoryManagementSystem.model.Product;


@RestController
@RequestMapping("/product")
public class ProductController {
	@Autowired
	 ProductService service ;
	
	  @GetMapping("/getAllProducts")
	    public List<Product> getAllTickets(){
	        return (List<Product>) service.getAllProducts();
	  }
	  @PostMapping(path="/createProduct")
	    public Product createProduct(@RequestBody Product product){
	        return service.createProduct(product);
	    }
	  @GetMapping("/getProductByProductName/{productName:.+}")
	    public Product getProductByProductName(@PathVariable String productName){
	        return service.findProductByProductName(productName);
	    }
	  @GetMapping("/getProductByCategeory/{Category:.+}")
	    public Product getProductByCategory(@PathVariable String category){
	        return service.findProductByProductName(category);
	    }
	  @GetMapping("/deleteProduct")
	    public boolean deleteProductbasedOnRating(){
	        return service.deleteProduct();
	    }
}
