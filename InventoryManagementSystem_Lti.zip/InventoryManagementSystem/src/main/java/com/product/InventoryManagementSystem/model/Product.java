package com.product.InventoryManagementSystem.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;


	
	@Entity
	@Table(name = "product_data")
	public class Product {
		@Id
		@GeneratedValue(strategy = GenerationType.AUTO)
		private long id;

		@Column(name = "category", nullable = false)
		
		private String Category;
		@Column(name = "name", nullable = false)
		private String Name;
		@Column(name = "quantity", nullable = false)
		private long Quantity;
		@Column(name = "unitPrice", nullable = false)
		private long UnitPrice;
		@Column(name = "rating", nullable = false)
		private long Rating;
		@Column(name = "totalPrice", nullable = false)
		private long TotalPrice;
		@Column(name = "productid", nullable = false)
		private int productId;
		@Override
		public String toString() {
			return "Product [id=" + id + ", Category=" + Category + ", Name=" + Name + ", Quantity=" + Quantity
					+ ", UnitPrice=" + UnitPrice + ", Rating=" + Rating + ", TotalPrice=" + TotalPrice + ", productId="
					+ productId + "]";
		}
		public long getId() {
			return id;
		}
		public void setId(long id) {
			this.id = id;
		}
		public String getCategory() {
			return Category;
		}
		public void setCategory(String category) {
			Category = category;
		}
		public String getName() {
			return Name;
		}
		public void setName(String name) {
			Name = name;
		}
		public long getQuantity() {
			return Quantity;
		}
		public void setQuantity(long quantity) {
			Quantity = quantity;
		}
		public long getUnitPrice() {
			return UnitPrice;
		}
		public void setUnitPrice(long unitPrice) {
			UnitPrice = unitPrice;
		}
		public long getRating() {
			return Rating;
		}
		public void setRating(long rating) {
			Rating = rating;
		}
		public long getTotalPrice() {
			return TotalPrice;
		}
		public void setTotalPrice(long totalPrice) {
			TotalPrice = totalPrice;
		}
		public int getProductId() {
			return productId;
		}
		public void setProductId(int productId) {
			this.productId = productId;
		}
		public Product(long id, String category, String name, long quantity, long unitPrice, long rating,
				long totalPrice, int productId) {
			super();
			this.id = id;
			Category = category;
			Name = name;
			Quantity = quantity;
			UnitPrice = unitPrice;
			Rating = rating;
			TotalPrice = totalPrice;
			this.productId = productId;
		}
		
		

}
